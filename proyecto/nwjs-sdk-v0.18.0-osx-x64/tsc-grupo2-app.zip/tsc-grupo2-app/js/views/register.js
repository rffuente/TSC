var loginView = {
  init: function() {
    $('#user_name').val('');
    $('#full_name').val('');
    $('#email').val('');
    $('#password').val('');

    $('#button-register').prop('disabled', true);

    $('#full_name, #user_name, #email, #password').on('keyup change click', function() {
      if ($('#full_name').val() != '' && $('#user_name').val() != '' && $('#email').val() != '' && $('#password').val() != '')
        $('#button-register').prop('disabled', false);
    });

    $('#button-register').click(function() {
      var data = {}
      data.full_name = $('#full_name').val();
      data.user_name = $('#user_name').val();
      data.email = $('#email').val();
      data.password = $('#password').val();

      users.post(data);
    });

    $('#button-back-index').click(function() {
      window.location.href = 'login.html';
    });
  }
}
