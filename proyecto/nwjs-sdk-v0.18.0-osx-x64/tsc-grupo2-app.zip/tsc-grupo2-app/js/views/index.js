var indexView = {
	init: function() {
		email = window.localStorage.getItem('email_user');
    password = window.localStorage.getItem('password_user');

    if (email && password) {
      data = {};
      data.email = email;
      data.password = password;

      auth.post(data);
    }
		
		$('#login').click(function() {
			window.location.href = "login.html";
    });

    $('#register').click(function() {
      window.location.href = "register.html";
    });
  }
}
