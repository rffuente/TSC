var tagsFromNoteView = {
  init: function(id) {
    navbarView.init();
    notes.get_unique(id);
    tags.get_tags_from_note(id);
    tags.get_available();

    window.sessionStorage.setItem('id', id);

    $('#modify-tag-button').click(function() {
      var data = {};
      data.title = $('#title').val();
      data.description = $('#description').val();

      if($('#title').val() != '' && $('#description').val() != '')
        notes.patch(data, window.sessionStorage.getItem('id'));
    })
  },

  setData: function(data) {
    document.getElementById('header').innerHTML = data.title;
    document.getElementById('title').value= data.title;
    document.getElementById('description').value= data.description;
  },

  buildTable: function(data) {
    var table  = $('#tabla-etiquetas').DataTable({
      data: data,
      columns: [
        { title: "Título ", data: "tag_name"},
        { title: "Descripción", data: "description"},
        { title: "Fecha de creación", data: "created_at"},
        { title: "Detalles", data : null, "defaultContent": "<div class='text-center'><button class='btn btn-success'>Ver</button></div>" },
        { title: "Eliminar", data : null, "defaultContent": "<div class='text-center'><button class='btn btn-danger'><span class='glyphicon glyphicon-trash'></span></button></div>" }
      ]
    });

    $('#tabla-etiquetas tbody').on('click', '.btn-success', function() {
      var data = table.row($(this).parents('tr')).data();
      window.location.href = "notes_from_tag.html?id=" + data.id;
    });

    $('#tabla-etiquetas tbody').on('click', '.btn-danger', function() {
      var data = table.row($(this).parents('tr')).data();
      window.sessionStorage.setItem("selected_tag", data.id);
      $('#tag-delete-modal').modal('show');
    });

    $('#confirm-tag-delete').click(function() {
      var erased_tag = window.sessionStorage.getItem("selected_tag");
      tags.delete(erased_tag);
    });
  },

  buildTableAvailables: function(data) {
    var table  = $('#tabla-etiquetas-disponibles').DataTable({
      data: data,
      columns: [
        { title: "Título", data: "tag_name"},
        { title: "Descripción", data: "description"},
        { title: "Asignar", data : null, "defaultContent": "<div class='text-center'><button class='btn btn-primary'><span class='glyphicon glyphicon-tag'></span></button></div>" }
      ]
    });

    $('#tabla-etiquetas-disponibles tbody').on('click', '.btn-primary', function() {
      var data = table.row($(this).parents('tr')).data();
      notes.assign_tag(window.sessionStorage.getItem('id'), data.id);
    });

  }

}
