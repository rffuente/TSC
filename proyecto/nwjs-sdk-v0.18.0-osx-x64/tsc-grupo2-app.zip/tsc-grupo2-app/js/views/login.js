var loginView = {
  init: function() {
    $('#email').val('');
    $('#password').val('');

    $('#button-login').prop('disabled', true);

    $('#button-login').click(function() {
      data = {};
      data.email = $('#email').val();
      data.password = $('#password').val();

      window.localStorage.setItem('email_user', $('#email').val());
      window.localStorage.setItem('password_user', $('#password').val());
      auth.post(data);
    });

    $('#email, #password').on('keyup change click', function() {
      if ($('#email').val() != '' && $('#password').val() != '')
        $('#button-login').prop('disabled', false);
    });

    $('#button-register').click(function() {
      window.location.href = 'register.html';
    });
  }
}
