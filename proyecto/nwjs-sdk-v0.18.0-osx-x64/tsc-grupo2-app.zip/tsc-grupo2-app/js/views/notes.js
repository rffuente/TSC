var notesView = {
  init: function() {
    navbarView.init();
    notes.get_all();

    $('#new-note-button').click(function() {
      var data = {};
      data.title = $('#title').val();
      data.description = $('#description').val();
      notes.post(data);
    })
  },

  buildTable: function(data) {
    var table  = $('#tabla-notes').DataTable({
      data: data,
      columns: [
        { title: "Titulo ", data: "title"},
        { title: "Descripción", data: "description"},
        { title: "Fecha de creación", data: "created_at"},
        { title: "Detalles", data : null, "defaultContent": "<div class='text-center'><button class='btn btn-success'>Ver</button></div>" },
        { title: "Eliminar", data : null, "defaultContent": "<div class='text-center'><button class='btn btn-danger'><span class='glyphicon glyphicon-trash'></span></button></div>" }
      ]
    });

    $('#tabla-notes tbody').on('click', '.btn-success', function() {
      var data = table.row($(this).parents('tr')).data();
      window.location.href = "tags_from_note.html?id=" + data.id;
    });

    $('#tabla-notes tbody').on( 'click', '.btn-danger', function() {
      var data = table.row($(this).parents('tr')).data();
      window.sessionStorage.setItem("selected_note", data.id);
      $('#note-delete-modal').modal('show');
    });

    $('#confirm-note-delete').click(function() {
      var erased_note = window.sessionStorage.getItem("selected_note");
      notes.delete(erased_note);
    });
  }
}
