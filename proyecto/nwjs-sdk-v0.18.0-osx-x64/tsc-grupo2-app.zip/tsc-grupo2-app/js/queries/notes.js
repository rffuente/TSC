var notes = {
  get_all: function() {
    $.ajax({
      url: "http://localhost:9999/notes/",
      data: {},
      type: "GET",
      dataType: "json",
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function(json) {
        notesView.buildTable(json);
      },
      error: function() {
        alert("Error al obtener los datos de las notas.");
      },
      complete: function() {

      }
    });
  },

  get_unique: function(id) {
    $.ajax({
      url: "http://localhost:9999/notes/" + id,
      data: {},
      type: "GET",
      dataType: "json",
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function(json) {
        tagsFromNoteView.setData(json);
      },
      error: function() {
        alert("Error al obtener los datos de la nota.");
      },
      complete: function() {

      }
    });
  },

  get_notes_from_tag: function(id) {
    $.ajax({
      url: "http://localhost:9999/tags/" + id + "/notes",
      data: {},
      type: "GET",
      dataType: "json",
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function(json) {
        notesFromTagView.buildTable(json);
      },
      error: function() {
        alert("Error al obtener las notas asociadas a la etiqueta.");
      },
      complete: function() {

      }
    });
  },

  post: function(data) {
    $.ajax({
      url: "http://localhost:9999/notes/",
      data: JSON.stringify({
        title: data.title,
        description: data.description
      }),
      contentType: "application/json; charset=UTF-8",
      dataType: "json",
      type: "POST",
      processData: false,
      timeout: 30000,
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function() {
        alert("Nota creada con éxito.");
        location.reload();
      },
      error: function() {
        alert("Error al crear la nota.");
      },
      complete: function() {

      }
    });
  },

  assign_tag: function(note_id, tag_id) {
    $.ajax({
      url: "http://localhost:9999/notes/" + note_id + "/assign_tag/",
      data: JSON.stringify({
        tag_id: tag_id
      }),
      contentType: "application/json; charset=UTF-8",
      dataType: "json",
      type: "POST",
      processData: false,
      timeout: 30000,
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function() {
        alert("Etiqueta asignada con éxito.");
        location.reload();
      },
      error: function() {
        alert("Error al asignar la etiqueta.");
      },
      complete: function() {

      }
    });
  },

  delete: function(id) {
    $.ajax({
      url: "http://localhost:9999/notes/" + id,
      contentType: "application/json; charset=UTF-8",
      dataType: "json",
      type: "DELETE",
      processData: false,
      timeout: 30000,
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function() {
        alert("Nota borrada con éxito.");
        location.reload();
      },
      error: function() {
        alert("Error al borrar la nota.");
      },
      complete: function() {

      }
    });
  },

  patch: function(data, id) {
    $.ajax({
      url: "http://localhost:9999/notes/" + id,
      data: JSON.stringify({
        title: data.title,
        description: data.description
      }),
      contentType: "application/json; charset=UTF-8",
      dataType: "json",
      type: "PATCH",
      processData: false,
      timeout: 30000,
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function() {
        alert("Nota modificada con éxito.");
        location.reload();
      },
      error: function() {
        alert("Error al modificar la nota.");
      },
      complete: function() {

      }
    });
  }
};
