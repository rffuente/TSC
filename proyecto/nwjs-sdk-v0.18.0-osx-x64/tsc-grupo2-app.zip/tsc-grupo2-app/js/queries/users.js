var users = {
  post: function(data) {
    $.ajax({
      url: "http://localhost:9999/users",
      data: JSON.stringify({
        full_name: data.full_name,
        user_name: data.user_name,
        email: data.email,
        password: data.password
      }),
      contentType: "application/json; charset=UTF-8",
      dataType: "json",
      type: "POST",
      processData: false,
      timeout: 30000,
      success: function() {
        alert("Usuario Creado");
        window.location.href = 'notes.html';
      },
      error: function() {
        alert("Error al crear el usuario");
      },
      complete: function() {

      }
    });
  }
};
