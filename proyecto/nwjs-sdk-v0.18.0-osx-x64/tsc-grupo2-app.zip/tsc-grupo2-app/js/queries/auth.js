var auth = {
  post: function(data) {
    $.ajax({
      url : "http://localhost:9999/users/login",
      data : JSON.stringify({
        credentials: btoa(data.email + ':' + data.password)
      }),
      contentType : "application/json; charset=UTF-8",
      dataType : "json",
      type : "POST",
      processData : false,
      timeout : 30000,
      success: function() {
        window.location.href = 'notes.html';
      },
      error: function() {
        window.localStorage.setItem('email_user', '');
        window.localStorage.setItem('password_user', '');

        alert("Error en el Login. Revise que sus credenciales sean las correctas");
      },
      complete: function() {

      }
    });
  }
};
