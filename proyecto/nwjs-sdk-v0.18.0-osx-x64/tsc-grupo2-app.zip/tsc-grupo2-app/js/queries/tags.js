var tags = {
  get_all: function() {
    $.ajax({
      url: "http://localhost:9999/tags/",
      data: {},
      type: "GET",
      dataType: "json",
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function(json) {
        tagsView.buildTable(json);
      },
      error: function() {
        alert("Error al obtener los datos de las etiquetas.");
      },
      complete: function() {

      }
    });
  },

  get_available: function() {
    $.ajax({
      url: "http://localhost:9999/tags/",
      data: {},
      type: "GET",
      dataType: "json",
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function(json) {
        tagsFromNoteView.buildTableAvailables(json);
      },
      error: function(xhr) {
        console.log(xhr);
        alert("Error al obtener los datos de las etiquetas.");
      },
      complete: function() {

      }
    });
  },

  get_unique: function(id) {
    $.ajax({
      url: "http://localhost:9999/tags/" + id,
      data: {},
      type: "GET",
      dataType: "json",
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function(json) {
        notesFromTagView.setData(json);
      },
      error: function() {
        alert("Error al obtener los datos de la etiqueta.");
      },
      complete: function() {

      }
    });
  },

  get_tags_from_note: function(id) {
    $.ajax({
      url: "http://localhost:9999/notes/" + id + "/tags",
      data: {},
      type: "GET",
      dataType: "json",
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function(json) {
        tagsFromNoteView.buildTable(json);
      },
      error: function() {
        alert("Error al obtener las etiquetas asociadas a la nota.");
      },
      complete: function() {

      }
    });
  },

  post: function(data) {
    $.ajax({
      url: "http://localhost:9999/tags/",
      data: JSON.stringify({
        tag_name: data.tag_name,
        description: data.description
      }),
      contentType: "application/json; charset=UTF-8",
      dataType: "json",
      type: "POST",
      processData: false,
      timeout: 30000,
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function() {
        alert("Etiqueta creada con éxito.");
        location.reload();
      },
      error: function() {
        alert("Error al crear la etiqueta.");
      },
      complete: function() {

      }
    });
  },

  delete: function(id) {
    $.ajax({
      url: "http://localhost:9999/tags/" + id,
      contentType: "application/json; charset=UTF-8",
      dataType: "json",
      type: "DELETE",
      processData: false,
      timeout: 30000,
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function() {
        alert("Etiqueta borrada con éxito.");
        location.reload();
      },
      error: function() {
        alert("Error al borrar la etiqueta.");
      },
      complete: function() {

      }
    });
  },

  patch: function(data, id) {
    $.ajax({
      url: "http://localhost:9999/tags/" + id,
      data: JSON.stringify({
        tag_name: data.tag_name,
        description: data.description
      }),
      contentType: "application/json; charset=UTF-8",
      dataType: "json",
      type: "PATCH",
      processData: false,
      timeout: 30000,
      beforeSend: function(xhr) {
        token = btoa(window.localStorage.getItem('email_user') + ':' + window.localStorage.getItem('password_user'));

        xhr.setRequestHeader("Authorization", token);
      },
      success: function() {
        alert("Etiqueta modificada con éxito.");
        location.reload();
      },
      error: function() {
        alert("Error al modificar la etiqueta.");
      },
      complete: function() {

      }
    });
  }
};
