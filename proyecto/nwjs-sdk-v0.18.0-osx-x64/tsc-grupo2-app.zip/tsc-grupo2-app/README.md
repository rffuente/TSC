# README

* IP de la maquina: 10.10.15.211

* Framework utilizado: NW.js v0.18.5 SDK

* Raíz del proyecto: /home/tsc-grupo2-app

* Webserver utilizado: apache

* Ubicación de los archivos de configuración: /etc/httpd/conf.d.
